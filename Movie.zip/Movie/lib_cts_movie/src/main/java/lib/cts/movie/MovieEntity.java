package lib.cts.movie;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Data
@Table(name = "MovieEntity")
public class MovieEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int movieId;
    @Column(name = "movieName")
    private String movieName;
    @Column(name = "movieGenre")
    private String movieGenre;
}
