package lib.cts.movie;

public class MovieDTO {

    private int movieId;
    private String movieName;
    private String movieGenre;
}
