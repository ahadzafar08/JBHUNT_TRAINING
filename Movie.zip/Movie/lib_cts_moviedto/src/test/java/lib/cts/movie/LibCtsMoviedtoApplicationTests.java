package lib.cts.movie;

import org.junit.Test;
//import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibCtsMoviedtoApplicationTests {

    @Test
    void contextLoads() {
    }

}
