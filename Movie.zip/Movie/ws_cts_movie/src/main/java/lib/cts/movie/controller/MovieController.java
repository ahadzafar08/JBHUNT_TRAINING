package lib.cts.movie.controller;


import lib.cts.movie.MovieDTO;
import lib.cts.movie.MovieEntity;

import lib.cts.movie.mapper.MovieMapper;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;
import lib.cts.movie.service.MovieService;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/cont")
@AllArgsConstructor
public class MovieController {

    @Autowired
    private MovieService movieService;


    @GetMapping("/movies")
    public ResponseEntity<List<MovieEntity>> getAllMovies()
    {
        List<MovieEntity> movieEntities=movieService.getAllMovies();
        return !CollectionUtils.isEmpty(movieEntities) ? new ResponseEntity<>(HttpStatus.FOUND)
                : new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @PostMapping("/movies")
    public ResponseEntity<List<MovieEntity>> postMovies(@RequestBody List<MovieDTO> movieDTO)
    {
        List<MovieEntity> movieEntities=movieService.postMovies(movieDTO);
        return !CollectionUtils.isEmpty(movieEntities) ? new ResponseEntity<>(HttpStatus.FOUND)
                : new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
