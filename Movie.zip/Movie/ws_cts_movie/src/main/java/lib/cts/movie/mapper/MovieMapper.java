package lib.cts.movie.mapper;

import lib.cts.movie.MovieDTO;
import lib.cts.movie.MovieEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE,componentModel = "spring")
public interface MovieMapper {
    @Mapping(source = "movieId",target="movieId")
    @Mapping(source = "movieName",target="movieName")
    @Mapping(source = "movieGenre",target="movieGenre")
    MovieEntity toMovieEntity(MovieDTO movieDTO);


    @Mapping(source = "movieId",target="movieId")
    @Mapping(source = "movieName",target="movieName")
    @Mapping(source = "movieGenre",target="movieGenre")
    MovieDTO toMovieDTO(MovieEntity movieEntity);


}
