package lib.cts.movie.repository;

import lib.cts.movie.MovieEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RestController;

@Repository
public interface MovieRepository extends JpaRepository<MovieEntity,Integer> {
}
