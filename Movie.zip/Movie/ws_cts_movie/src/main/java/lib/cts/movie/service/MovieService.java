package lib.cts.movie.service;

import lib.cts.movie.MovieDTO;
import lib.cts.movie.MovieEntity;
import lib.cts.movie.mapper.MovieMapper;
import lib.cts.movie.repository.MovieRepository;
import lombok.AllArgsConstructor;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;


@Service
@AllArgsConstructor
public class MovieService {

    @Autowired
    private MovieRepository movieRepository;

    @SuppressWarnings("SpringJavaInjectionPointsAutowiringInspection")
    @Autowired
    private MovieMapper movieMapper;

    public List<MovieEntity> getAllMovies()
    {
        List<MovieEntity> movieEntities=movieRepository.findAll();
        return  movieEntities;
    }

    public  List<MovieEntity> postMovies(List<MovieDTO> movieDTO)
    {
        List<MovieEntity> movieEntities=movieDTO
                .stream()
                .map(movieDTO1 -> movieMapper.toMovieEntity(movieDTO1))
                .collect(Collectors.toList());
        return movieRepository.saveAll(movieEntities);
    }
}
